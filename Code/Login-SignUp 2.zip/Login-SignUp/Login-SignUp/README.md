# Login-SignUp-MinimalUI-Animation
Here is an example of beautiful UI for login & SignUp screen with the best Animation between them, This animation is done with the popular Constraintlayout.
<br><br>
it is easy to animate scenes without a lot of code. Animations make your app look polished, improve engagement, and are fun to build. Check out this example to find out More!


<br><img src="https://drive.google.com/uc?id=1LOsxPNLh7LTy6spjoYoJl2W7kHMFlKa1"/>


# A Beautiful Animation!
<br><img src="https://drive.google.com/uc?id=1IqeTFIn02xzi-7mH_MxipU1-toaNAxRT"/><br><br> (It's more smoother than Gif in App😍)




# How to contribute?
Fork the project. 💖 Happy coding.:-)

# License
<b>This Project</b> is licensed under `MIT license`. View [license](LICENSE).
